// Precios de referencia (ARS) que usa el presupuestador.
// Se calculan según el dólar oficial y pueden variar: actualizarlos acá.
export interface Precio {
  id: string;
  servicio: string;
  incluye: string;
  min: number;
  max: number;
}

export const PRECIOS: Precio[] = [
  {
    id: 'automatizacion',
    servicio: 'Automatizaciones para tu negocio',
    incluye: 'Un proceso que se hace solo: planillas, avisos, reportes, integraciones',
    min: 500_000,
    max: 1_500_000,
  },
  {
    id: 'asistentes',
    servicio: 'Asistente para tu web o sistema',
    incluye: 'Asistente guiado que responde a tus clientes (con inteligencia artificial, desde $1.500.000)',
    min: 450_000,
    max: 1_200_000,
  },
  {
    id: 'bots-whatsapp',
    servicio: 'Bot de WhatsApp',
    incluye: 'Responde y toma pedidos a toda hora, con menú y derivación a una persona',
    min: 1_500_000,
    max: 3_000_000,
  },
  {
    id: 'paginas-web',
    servicio: 'Página web',
    incluye: 'Página para tu negocio, con formularios conectados, automatizaciones y asistente',
    min: 900_000,
    max: 2_000_000,
  },
  {
    id: 'ciberseguridad',
    servicio: 'Ciberseguridad',
    incluye: 'Revisión de seguridad de tu negocio con informe y recomendaciones',
    min: 500_000,
    max: 1_200_000,
  },
  {
    id: 'software',
    servicio: 'Software a medida',
    incluye: 'Sistema pensado para tu rubro: gestión, turnos, stock, ventas',
    min: 2_500_000,
    max: 4_000_000,
  },
];

// Abonos mensuales (se suman aparte del pago único).
export interface Abono {
  id: string;
  nombre: string;
  detalle: string;
  // null = se ofrece pero el precio todavía no se publica ("A consultar").
  mensual: number | null;
  // true = se muestra como "Próximamente" y no se puede elegir.
  proximamente?: boolean;
}

export const ABONOS: Abono[] = [
  {
    id: 'tero',
    nombre: 'TERO Security',
    detalle: 'nuestro software de ciberseguridad: revisa y vigila tu negocio, con avisos e informes',
    mensual: null,
    proximamente: true,
  },
  {
    id: 'soporte',
    nombre: 'Soporte y mantenimiento mensual',
    detalle: 'ajustes, monitoreo y soporte de lo que armamos',
    mensual: 150_000,
  },
];

export const pesos = (n: number): string =>
  '$' + n.toLocaleString('es-AR', { maximumFractionDigits: 0 });
